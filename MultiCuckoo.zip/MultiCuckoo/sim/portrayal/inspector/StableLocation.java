package sim.portrayal.inspector;

public abstract interface StableLocation
{
  public abstract String toString();
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.portrayal.inspector.StableLocation
 * JD-Core Version:    0.6.2
 */