package sim.portrayal.inspector;

public abstract interface Tabbable
{
  public abstract String[] provideTabNames();

  public abstract String[][] provideTabProperties();

  public abstract String provideExtraTab();
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.portrayal.inspector.Tabbable
 * JD-Core Version:    0.6.2
 */