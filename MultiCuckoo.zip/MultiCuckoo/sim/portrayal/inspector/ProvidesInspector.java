package sim.portrayal.inspector;

import sim.display.GUIState;
import sim.portrayal.Inspector;

public abstract interface ProvidesInspector
{
  public abstract Inspector provideInspector(GUIState paramGUIState, String paramString);
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.portrayal.inspector.ProvidesInspector
 * JD-Core Version:    0.6.2
 */