package sim.portrayal;

public abstract interface Scalable2D
{
  public abstract double getScale2D();

  public abstract void setScale2D(double paramDouble);
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.portrayal.Scalable2D
 * JD-Core Version:    0.6.2
 */