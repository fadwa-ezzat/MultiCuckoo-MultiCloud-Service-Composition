package sim.portrayal;

public abstract interface Fixed2D
{
  public abstract boolean maySetLocation(Object paramObject1, Object paramObject2);
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.portrayal.Fixed2D
 * JD-Core Version:    0.6.2
 */