package sim.portrayal;

public abstract interface Orientable2D extends Oriented2D
{
  public abstract void setOrientation2D(double paramDouble);
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.portrayal.Orientable2D
 * JD-Core Version:    0.6.2
 */