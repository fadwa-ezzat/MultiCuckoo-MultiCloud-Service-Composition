package sim.portrayal;

public abstract interface Oriented2D
{
  public abstract double orientation2D();
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.portrayal.Oriented2D
 * JD-Core Version:    0.6.2
 */