package sim.portrayal.simple;

import java.awt.Paint;
import sim.portrayal.SimplePortrayal2D;

public class AbstractShapePortrayal2D extends SimplePortrayal2D
{
  public Paint paint;
  public double scale;
  public boolean filled;
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.portrayal.simple.AbstractShapePortrayal2D
 * JD-Core Version:    0.6.2
 */