package sim.portrayal;

import java.awt.Graphics2D;

public abstract interface Portrayal2D extends Portrayal
{
  public abstract void draw(Object paramObject, Graphics2D paramGraphics2D, DrawInfo2D paramDrawInfo2D);
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.portrayal.Portrayal2D
 * JD-Core Version:    0.6.2
 */