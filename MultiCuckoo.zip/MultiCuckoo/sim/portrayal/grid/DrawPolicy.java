package sim.portrayal.grid;

import sim.util.Bag;

public abstract interface DrawPolicy
{
  public abstract boolean objectToDraw(Bag paramBag1, Bag paramBag2);
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.portrayal.grid.DrawPolicy
 * JD-Core Version:    0.6.2
 */