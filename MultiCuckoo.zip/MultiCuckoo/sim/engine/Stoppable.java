package sim.engine;

import java.io.Serializable;

public abstract interface Stoppable extends Serializable
{
  public abstract void stop();
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.engine.Stoppable
 * JD-Core Version:    0.6.2
 */