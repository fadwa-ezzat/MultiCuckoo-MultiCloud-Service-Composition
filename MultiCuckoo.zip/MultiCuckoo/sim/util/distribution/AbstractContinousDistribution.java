package sim.util.distribution;

public abstract class AbstractContinousDistribution extends AbstractDistribution
{
  private static final long serialVersionUID = 1L;
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.util.distribution.AbstractContinousDistribution
 * JD-Core Version:    0.6.2
 */