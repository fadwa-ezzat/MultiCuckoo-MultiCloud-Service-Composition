package sim.util.gui;

abstract interface WordWrapScanner
{
  public abstract int scan(StringBuilder paramStringBuilder, int paramInt, double paramDouble);
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.util.gui.WordWrapScanner
 * JD-Core Version:    0.6.2
 */