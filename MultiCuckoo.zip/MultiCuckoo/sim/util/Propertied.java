package sim.util;

public abstract interface Propertied
{
  public abstract Properties properties();
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.util.Propertied
 * JD-Core Version:    0.6.2
 */