package sim.util;

public abstract interface Valuable
{
  public abstract double doubleValue();
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.util.Valuable
 * JD-Core Version:    0.6.2
 */