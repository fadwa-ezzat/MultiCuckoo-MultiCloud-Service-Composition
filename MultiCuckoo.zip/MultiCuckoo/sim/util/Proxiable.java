package sim.util;

public abstract interface Proxiable
{
  public abstract Object propertiesProxy();
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.util.Proxiable
 * JD-Core Version:    0.6.2
 */