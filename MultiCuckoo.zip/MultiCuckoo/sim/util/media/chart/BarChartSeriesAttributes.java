/*    */ package sim.util.media.chart;
/*    */ 
/*    */ import org.jfree.data.general.SeriesChangeListener;
/*    */ 
/*    */ public class BarChartSeriesAttributes extends PieChartSeriesAttributes
/*    */ {
/*    */   public BarChartSeriesAttributes(ChartGenerator generator, String name, int index, SeriesChangeListener stoppable)
/*    */   {
/* 36 */     super(generator, name, index, stoppable);
/*    */   }
/*    */ }

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.util.media.chart.BarChartSeriesAttributes
 * JD-Core Version:    0.6.2
 */