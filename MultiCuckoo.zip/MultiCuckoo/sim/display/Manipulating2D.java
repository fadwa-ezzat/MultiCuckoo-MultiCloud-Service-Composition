package sim.display;

import sim.portrayal.LocationWrapper;

public abstract interface Manipulating2D
{
  public abstract void performSelection(LocationWrapper paramLocationWrapper);

  public abstract void setMovingWrapper(LocationWrapper paramLocationWrapper);
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.display.Manipulating2D
 * JD-Core Version:    0.6.2
 */