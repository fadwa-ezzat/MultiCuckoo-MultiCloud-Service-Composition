package sim.app.pacman;

public class Energizer
{
  private static final long serialVersionUID = 1L;
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.app.pacman.Energizer
 * JD-Core Version:    0.6.2
 */