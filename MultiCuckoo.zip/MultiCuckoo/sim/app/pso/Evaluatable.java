package sim.app.pso;

public abstract interface Evaluatable
{
  public abstract double calcFitness(double paramDouble1, double paramDouble2);
}

/* Location:           D:\To Dr-Leena\To Dr-Leena\MultiCuckoo.jar
 * Qualified Name:     sim.app.pso.Evaluatable
 * JD-Core Version:    0.6.2
 */